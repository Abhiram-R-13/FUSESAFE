# Case A R02 loading-verification handoff

Exported 2 November 2026 from the user's restored R02 LoadVerification working copy in Mechanical 2025 R1. Original archives were not edited. Retained mesh: 4961 nodes, 1600 Quad8 elements. No mesh regeneration, loads, supports, or solve requested by this export. Solver input export produced an insufficient-restraints warning, expected for this unrestrained model.

## Data and conventions

- `nodes_native.csv`: full double-precision mesh coordinates, **metres**, global Cartesian; 17 significant digits. These mesh API coordinates retain more printed precision than the solver input deck.
- `elements.csv`: element IDs, API type kQuad8, eight node IDs in original local order. Solver deck confirms `et,1,281` (SHELL281). Corners n1,n2,n3,n4; midsides n5 on 1–2, n6 on 2–3, n7 on 3–4, n8 on 4–1.
- `region_nodes.csv` and `regions.csv`: exact exported geometry entity memberships. A_Skin face ID **9**; A_CircumferentialSides IDs **7,6**; A_AxialEnds IDs **5,4**. All 1600 shell elements belong to the one retained skin face.
- `boundary_edges.csv`: 160 quadratic boundary segments, 40 per CAD edge. Each row gives adjacent element, two endpoints and midside node, integrated length and line centroid. Local endpoint direction follows element perimeter; it is not necessarily increasing global X or angle.
- `boundary_*_element_membership.csv`: source mesh-membership audit, including original element-local indices.
- `boundary_summary.csv`: exact boundary grouping, lengths, mean NODE coordinates (not line centroids), proposed benchmark line tractions and integrated resultants.
- `element_geometry.csv`: mapped element centre coordinates, raw unit normal there, outward sign, area, outward vector area and moment-area integrals; minimum Jacobian magnitude sampled at 3x3 Gauss points. All 1600 raw centre normals point outward. Normals vary across each curved element: use shape derivatives for integration rather than multiplying centre normal by scalar area. Minimum sampled Jacobian is not a proof over the complete element.
- `R02_solver_input.dat`: solver connectivity, sections and model export; exported successfully without solve.
- `metadata.txt`: original mesh unit, bounds, body properties and candidate restraint coordinates.
- `candidate_restraint_nodes.csv`: nodes 1178,1143,1229 in metres and millimetres. These are verified coordinates, **not approval of the proposed restraints**.
- `integration_check.json`: computed force/moment check. `verify_R02.m` reproduces the quadrature in MATLAB; MATLAB execution remains for Member 4. The numerical calculation here ran in JavaScript using analytic Quad8 derivatives and 3x3 surface / 3-point edge Gauss quadrature.

## Confirmed geometry and section

Axis X; nominal midsurface R=2 m, X=0..1.6 m, angular span -0.4..+0.4 rad in YZ with centre outward +Y. Nominal developed arc 1.6 m. Mesh Y bounds 1.842121988008936..2 m; Z bounds approximately +/-0.778836684609813 m. Integrated mesh area **2.5599999995825895 m²**; exported CAD surface area **2.5599999999739826 m²**.

Body properties confirm manual thickness, **0.002 m**, shell offset **Middle**, material FUSESAFE_2024_T3_PROVISIONAL. Solver section confirms `secdata,2.e-003` and `secoff,mid`. Thus nominal physical inner/outer radii are 1.999/2.001 m; exported mesh is at the midsurface.

| CAD edge ID | Boundary | Global location | Quadratic mesh length |
|---|---|---|---|
|4|Curved axial end|X=0; theta=-0.4..0.4 rad|1.5999999997170757 m|
|5|Curved axial end|X=1.6 m; theta=-0.4..0.4 rad|1.5999999997170755 m|
|6|Straight circumferential side|Y=1.84212198800894 m, Z=+0.778836684609813 m; X=0..1.6 m|approximately 1.6 m|
|7|Straight circumferential side|Y=1.84212198800894 m, Z=-0.778836684609813 m; X=0..1.6 m|approximately 1.6 m|

Each boundary has 81 unique nodes. Corner nodes belong to two boundaries by design.

## Pressure surface: what is and is not established

The skin is a single **midsurface shell face**, geometry ID 9 / A_Skin. There is no separate inner CAD face and no pressure object in the exported analysis tree. No existing pressure-side selection or solver pressure sign can therefore be certified from this model.

For the proposed benchmark, the intended traction is **outward radial**, p=55000 Pa, acting on the **exported shell reference surface**. All raw element centre normals agree with this direction. Member 1 must confirm Mechanical's pressure arrow/side and corresponding solver face/sign when creating the actual pressure object. This integration does not substitute the physical inner radius 1.999 m for the midsurface radius; a pressure defined on that physical surface would be a different loading convention.

## Proposed benchmark integration, not an applied load or structural solution

Global moment reference: (0,0,0) m. Pressure resultant approximately **(0,137075.256491327,0) N** and moment **(0,0,109660.2051930615) N m**. Boundary resultant approximately **(0,-137075.256492645,0) N**, moment **(0,0,-109660.2051941159) N m**.

Tractions used: X=0 edge (-55000,0,0) N/m; X=1.6 edge (+55000,0,0) N/m; Z-positive side (0,-42836.01765395156,+101316.70934031736) N/m; Z-negative side (0,-42836.01765395156,-101316.70934031736) N/m. These correspond to Nx=55 N/mm and Ntheta=110 N/mm. Each circumferential-side force has magnitude 176 kN, each axial-end force 88 kN. The two circumferential-side vectors are not globally opposite.

Combined residual magnitude approximately **1.318e-6 N**, moment residual approximately **1.054e-6 N m**, from the quadratic mesh quadrature. This supports external force/moment balance for these proposed fields. It does not verify implementation of pressure/edge loads in Mechanical, restraint stability, reaction equilibrium, convergence, stress accuracy or restraint sensitivity. No support or load has been applied by the scripts.

## Next owners' checks

Member 4: run MATLAB script, independently confirm solver node order/edge membership and pressure sign convention; use full-precision candidate coordinates. Member 1: implement agreed loads/supports only after restraint review, check load arrows and solver input, solve A first, then examine reactions, far-field stresses, deformation and restraint-location sensitivity. Keep shell rotations free as proposed pending support review. Initial expected far-field membrane stresses: hoop 55 MPa, axial 27.5 MPa, VM about 47.63 MPa. These are benchmark targets, not results.
